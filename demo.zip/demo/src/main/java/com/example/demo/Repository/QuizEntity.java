package com.example.demo.Repository;

import org.hibernate.engine.internal.Cascade;

import javax.persistence.*;
import java.util.Set;

@Entity
public class QuizEntity
{
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "noOfQuestions")
    private Integer noOfQuestions;

    @Column(name = "name")
    private String name;


}
