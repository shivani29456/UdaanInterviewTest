package com.example.demo.Service;

import com.example.demo.Repository.IQuestion;
import com.example.demo.Repository.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class QuestionService
{

    @Autowired
    private IQuestion iQuestion;

    public void create(QuestionBean bean)
    {
        QuestionEntity entity = new QuestionEntity(bean);
        iQuestion.save(entity);
    }
}
