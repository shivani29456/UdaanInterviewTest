package com.example.demo.Repository;

import com.example.demo.Service.QuestionBean;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
public class QuestionEntity
{
    // id, String , multiple possible answer, correct answer
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")

    private Integer id;

    @Column(name = "questionDescription",length = 1024)
    private String questionDescription;

    @Column(name = "possibleAnswers1", length = 255)
    private String possibleAnswer1;

    @Column(name = "possibleAnswers2", length = 255)
    private String possibleAnswer2;

    @Column(name = "possibleAnswers3", length = 255)
    private String possibleAnswer3;

    @Column(name = "possibleAnswers4", length = 255)
    private String possibleAnswer4;

    @Column(name = "correctAnswer", length = 255)
    private String correctAnswer;



    public QuestionEntity() {
    }

    public QuestionEntity(QuestionBean bean) {
        this.questionDescription = bean.getQuestionDescription();
        this.correctAnswer = bean.getCorrectAnswer();
        List<String> answers = bean.getPossibleAnswers();
        this.possibleAnswer1 = answers.get(0);
        this.possibleAnswer2 = answers.get(1);
        this.possibleAnswer3 = answers.get(2);
        this.possibleAnswer4 = answers.get(3);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionDescription() {
        return questionDescription;
    }

    public void setQuestionDescription(String questionDescription) {
        this.questionDescription = questionDescription;
    }

    public String getPossibleAnswer1() {
        return possibleAnswer1;
    }

    public void setPossibleAnswer1(String possibleAnswer1) {
        this.possibleAnswer1 = possibleAnswer1;
    }

    public String getPossibleAnswer2() {
        return possibleAnswer2;
    }

    public void setPossibleAnswer2(String possibleAnswer2) {
        this.possibleAnswer2 = possibleAnswer2;
    }

    public String getPossibleAnswer3() {
        return possibleAnswer3;
    }

    public void setPossibleAnswer3(String possibleAnswer3) {
        this.possibleAnswer3 = possibleAnswer3;
    }

    public String getPossibleAnswer4() {
        return possibleAnswer4;
    }

    public void setPossibleAnswer4(String possibleAnswer4) {
        this.possibleAnswer4 = possibleAnswer4;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }


}
