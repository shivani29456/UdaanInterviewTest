package com.example.demo.Controller;

import com.example.demo.Service.QuestionBean;
import com.example.demo.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/questions")
public class QuestionController
{
    @Autowired
    private QuestionService questionService;

   @RequestMapping(method = RequestMethod.POST,produces = {MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_JSON_VALUE})
    public Object createQuestion(@RequestBody QuestionDTO dto)
    {
        QuestionBean bean = new QuestionBean(dto);
        questionService.create(bean);
        return "Success";
    }
}
