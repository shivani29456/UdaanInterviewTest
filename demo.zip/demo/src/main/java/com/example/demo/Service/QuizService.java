package com.example.demo.Service;

import com.example.demo.Repository.IQuiz;
import org.springframework.beans.factory.annotation.Autowired;

public class QuizService
{
@Autowired
    private IQuiz quiz;



}
