package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IQuestion extends JpaRepository<QuestionEntity,Integer> {
}
