package com.example.demo.Controller;

import java.util.List;

public class QuizDTO
{
    private Integer id;

    private Integer noOfQuestions;

    private String name;

    private List<String> questionids;



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNoOfQuestions() {
        return noOfQuestions;
    }

    public void setNoOfQuestions(Integer noOfQuestions) {
        this.noOfQuestions = noOfQuestions;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getQuestionids() {
        return questionids;
    }

    public void setQuestionids(List<String> questionids) {
        this.questionids = questionids;
    }
}
