package com.example.demo.Controller;

import com.example.demo.Service.QuestionBean;

import java.util.List;

public class QuestionDTO
{
    private Integer id;

    private String questionDescription;

    private List<String> possibleAnswers;

    private String correctAnswer;

    public QuestionDTO() {
    }

   /* public QuestionDTO(QuestionBean bean) {
        this.id = bean.getId();
        this.questionDescription = bea
    }*/

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionDescription() {
        return questionDescription;
    }

    public void setQuestionDescription(String questionDescription) {
        this.questionDescription = questionDescription;
    }

    public List<String> getPossibleAnswers() {
        return possibleAnswers;
    }

    public void setPossibleAnswers(List<String> possibleAnswers) {
        this.possibleAnswers = possibleAnswers;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}
