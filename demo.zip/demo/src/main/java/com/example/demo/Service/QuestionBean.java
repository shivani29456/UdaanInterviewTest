package com.example.demo.Service;

import com.example.demo.Controller.QuestionDTO;
import com.example.demo.Repository.QuestionEntity;

import javax.persistence.Column;
import java.util.ArrayList;
import java.util.List;

public class QuestionBean
{
    private Integer id;

    private String questionDescription;

    private List<String> possibleAnswers;

    private String correctAnswer;

    public QuestionBean() {
    }

    public QuestionBean(QuestionDTO dto) {
        //this.id = dto.getId();
        this.questionDescription = dto.getQuestionDescription();
        this.correctAnswer = dto.getCorrectAnswer();
        this.possibleAnswers = dto.getPossibleAnswers();
    }

    public QuestionBean(QuestionEntity entity) {
        this.id = entity.getId();
        this.questionDescription = entity.getQuestionDescription();
        this.correctAnswer = entity.getCorrectAnswer();
        List<String> answers = new ArrayList<>();
        answers.add(entity.getPossibleAnswer1());
        answers.add(entity.getPossibleAnswer2());
        answers.add(entity.getPossibleAnswer3());
        answers.add(entity.getPossibleAnswer4());
        this.possibleAnswers = answers;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionDescription() {
        return questionDescription;
    }

    public void setQuestionDescription(String questionDescription) {
        this.questionDescription = questionDescription;
    }

    public List<String> getPossibleAnswers() {
        return possibleAnswers;
    }

    public void setPossibleAnswers(List<String> possibleAnswers) {
        this.possibleAnswers = possibleAnswers;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}
